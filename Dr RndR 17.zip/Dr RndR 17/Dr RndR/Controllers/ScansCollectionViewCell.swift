//
//  ScansCollectionViewCell.swift
//  Dr RndR
//
//  Created by Prabal Kumar on 26/04/24.
//

import UIKit

class ScansCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet var scanImageView: UIImageView!
    
    @IBOutlet var scanLabelView: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
