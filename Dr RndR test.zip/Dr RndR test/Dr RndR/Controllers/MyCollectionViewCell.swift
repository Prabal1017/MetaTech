//
//  MyCollectionViewCell.swift
//  Dr RndR
//
//  Created by Prabal Kumar on 25/04/24.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var myScanImage: UIImageView!
    
    
}
